import java.util.Scanner;

public class LetterCharCount {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Nhập chuỗi từ người dùng
        System.out.print("Enter a string: ");
        String input = sc.nextLine();

        // Đếm từ
        String[] words = input.split(" ");
        for (int i = 0; i < words.length; i++) {
            String word = words[i];
            int count = 1;
            // Bỏ qua nếu từ đã được đếm
            if (word.equals("")) continue;
            for (int j = i + 1; j < words.length; j++) {
                if (word.equalsIgnoreCase(words[j])) {
                    count++;
                    words[j] = ""; // Đánh dấu đã đếm
                }
            }
            System.out.println(word + " = " + count);
        }

        // Đếm chữ cái
        String lower = input.toLowerCase();
        boolean[] checked = new boolean[256]; // Dùng để đánh dấu đã đếm

        for (int i = 0; i < lower.length(); i++) {
            char ch = lower.charAt(i);
            if (Character.isLetter(ch) && !checked[ch]) {
                int count = 1;
                for (int j = i + 1; j < lower.length(); j++) {
                    if (lower.charAt(j) == ch) {
                        count++;
                    }
                }
                checked[ch] = true;
                System.out.println(ch + " = " + count);
            }
        }

        sc.close();
    }
}
