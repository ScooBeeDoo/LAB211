import java.util.Scanner;

public class BubbleSortLab3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of array: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Vui lòng nhập một số nguyên dương!");
            sc.close();
            return;
        }

        int[] arr = new int[n];
        System.out.print("Unsorted array: [");
        for (int i = 0; i < n; i++) {
            arr[i] = (int)(Math.random() * 100); 
            System.out.print(arr[i]);
            if (i < n - 1) {
                System.out.print(",");
            }
        }
        System.out.println("]");

        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false; 
            for (int j = 0; j < n - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
               
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            if (!swapped) {
                break;
            }
        }

        System.out.print("Sorted array: [");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i]);
            if (i < n - 1) {
                System.out.print(",");
            }
        }
        System.out.println("]");

        System.out.println("BUILD SUCCESSFUL (total time: 1 second)");

        sc.close();
    }
}