package lab211_p0021;
import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Studentmanager manager = new Studentmanager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Tao sinh vien");
            System.out.println("2. Tim kiem va sap xep");
            System.out.println("3. Cap nhat");
            System.out.println("4. Xoa");
            System.out.println("5. Bao cao");
            System.out.println("6. Hien thi danh sach");
            System.out.println("7. Sap xep danh sach");
            System.out.println("8. Thoat");
            System.out.print("Vui long chon (1-8): ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    manager.createStudent();
                    break;
                case "2":
                    manager.findAndSort();
                    break;
                case "3":
                    manager.update();
                    break;
                case "4":
                    manager.delete();
                    break;
                case "5":
                    manager.report();
                    break;
                case "6":
                    manager.showStudent();
                    break;
                case "7":
                    manager.sort();
                    break;
                case "8":
                    System.out.println("Tam biet!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Lua chon khong hop le! Vui long chon lai.");
            }
        }
    }
}