package lab211_p0021;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


  public class Studentmanager {
       private ArrayList<Student> studentList = new ArrayList<>();
       private Scanner scanner = new Scanner(System.in);
       
    private boolean checkIdExist(String id, String name){
           for (Student s : studentList){
             if(s.getId().equalsIgnoreCase(id) && s.getStudentName().equalsIgnoreCase(name)) {
                return false;
             }    
          }
           return true;
   }
    
    private boolean checkCourse(String c){
      return c.equalsIgnoreCase("JAVA") || c.equalsIgnoreCase(".Net") || c.equalsIgnoreCase("C/C++");
    }
    
    private boolean checkStudentExist(String name, String id, String semester, String course) {
           for (Student s : studentList) {
              if(s.getStudentName().equalsIgnoreCase(name) && s.getId().equalsIgnoreCase(id) 
                && s.getSemester().equalsIgnoreCase(semester) && s.getCourseName().equalsIgnoreCase(course)) {
                 return false;
              }          
           }  
            return true;
    }
    
        private ArrayList<Student> getStudentById(String id) {
       ArrayList<Student> result = new ArrayList<>();
        for (Student s : studentList) {
            if (s.getId().equalsIgnoreCase(id)) {
                result.add(s);
            }
        }
        return result;
    }
        
            private Student chooseStudent(ArrayList<Student> list) {
        System.out.println("Chon sinh vien:");
        for (int i = 0; i < list.size(); i++) {
            System.out.printf("%d. ", i + 1);
            list.get(i).print();
        }

        int choice = -1;
        while (choice < 1 || choice > list.size()) {
            System.out.print("Nhap lua chon (1-" + list.size() + "): ");
           try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (Exception e) {
                System.out.println("Nhap sai, thu lai.");
            }
        }
       return list.get(choice - 1);
    }
   public void createStudent() {
        System.out.println("Ban muon nhap bao nhieu sinh vien ?");
        int total = Integer.parseInt(scanner.nextLine());
        int count = 0;
        
        while(count < total){
            System.out.println("Nhap thong tin sinh vien thu "+ (count + 1));
            System.out.println("ID: ");
            String id = scanner.nextLine();
            System.out.println("Ho va ten: ");
            String name = scanner.nextLine();
            
            if(!checkIdExist(id, name)){
                System.out.println("ID ban dang ky da ton tai, vui long dang ky lai.");
                continue;
            }
            
            System.out.println("Hoc ky: ");
            String semester = scanner.nextLine();
            System.out.println("Mon hoc:");
            String course = scanner.nextLine();
            
            if(!checkCourse(course)) {
                System.out.println("Khoa hoc khong ton tai, vui long nhap lai.");
                continue;
            }
            
            if(checkStudentExist(id,name,semester,course)) {
               studentList.add(new Student(id,name,semester,course));
               count++;
                System.out.println("Them sinh vien thanh cong");
            } else {
                System.out.println("Thong tin sinh vien bi trung, vui long nhap lai.");
            }
        }  
   }
   
    public void findAndSort() {
        if(studentList.isEmpty()){
            System.out.println("Danh sach sinh vien trong.");
            return;
        }
        
        System.out.println("Nhap ID sinh vien muon tim: ");
        String id = scanner.nextLine();
        
        ArrayList<Student> result = new ArrayList<>();
         for(Student s : studentList) {
           if(s.getId().equalsIgnoreCase(id)) {
             result.add(s);
           }
         }
         
        if(result.isEmpty()){
            System.out.println("Khong tim thay sinh vien voi ID da nhap.");
        } else {
           System.out.printf("%-15s%-10s%-10s\n", "Ten", "Hoc ky", "Khoa hoc");
        for (Student s : result) {
           s.print();
            }
        }
    }
    
    
    public void update(){
       if(studentList.isEmpty()){
           System.out.println("Danh sach sinh vien trong.");
           return;
       }
       
        System.out.println("Nhap ID sinh vien muon cap nhat thong tin: ");
        String id = scanner.nextLine();
        
        ArrayList<Student> found = getStudentById(id);
        if(found.isEmpty()) {
            System.out.println("Khong tim thay ID sinh vien.");
            return;
        }
        Student s = chooseStudent(found);
        System.out.print("Nhap ten moi: ");
        String name = scanner.nextLine();
        System.out.print("Nhap hoc ky moi: ");
        String semester = scanner.nextLine();
        System.out.print("Nhap khoa hoc moi: ");
        String course = scanner.nextLine();

        if (checkCourse(course)) {
            s.setStudentName(name);
            s.setSemester(semester);
            s.setCourseName(course);
            System.out.println("Cap nhat thanh cong.");
        } else {
            System.out.println("Khoa hoc khong hop le.");
        }
        
        
        
    }
    
        public void delete() {
        if (studentList.isEmpty()) {
            System.out.println("Danh sach trong.");
            return;
       }

        System.out.print("Nhap ID sinh vien muon xoa: ");
        String id = scanner.nextLine();

        ArrayList<Student> found = getStudentById(id);
        if (found.isEmpty()) {
            System.out.println("Khong tim thay sinh vien.");
            return;
        }

        Student s = chooseStudent(found);
        studentList.remove(s);
        System.out.println("Da xoa sinh vien.");
    }
        
            public void report() {
        if (studentList.isEmpty()) {
            System.out.println("Danh sach trong.");
            return;
        }

        ArrayList<String> printed = new ArrayList<>();

        for (Student s : studentList) {
            String key = s.getStudentName() + "_" + s.getCourseName();
            if (printed.contains(key)) continue;

            int count = 0;
            for (Student s2 : studentList) {
                if (s.getStudentName().equalsIgnoreCase(s2.getStudentName()) &&
                    s.getCourseName().equalsIgnoreCase(s2.getCourseName())) {
                    count++;
                }
            }

            printed.add(key);
            System.out.printf("%-15s|%-10s|%d\n", s.getStudentName(), s.getCourseName(), count);
        }
    }

    public void showStudent() {
        if (studentList.isEmpty()) {
            System.out.println("Danh sach trong.");
            return;
        }

        System.out.printf("%-15s%-10s%-10s\n", "Ten", "Hoc ky", "Khoa hoc");
        for (Student s : studentList) {
            s.print();
        }
    }

    public void sort() {
        if (studentList.isEmpty()) {
            System.out.println("Danh sach trong.");
            return;
        }

        Collections.sort(studentList);
        System.out.println("Danh sach sau khi sap xep:");
       showStudent();
    }
  }
