import java.util.Scanner;

public class ConvertBiHexDe {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n Base Converter (Manual Algorithm) ");
            System.out.println("1. Binary");
            System.out.println("2. Decimal");
            System.out.println("3. Hexadecimal");

            System.out.print("Choose input base (1-3): ");
            int inputBaseChoice = sc.nextInt();

            System.out.print("Choose output base (1-3): ");
            int outputBaseChoice = sc.nextInt();

            int inputBase = getBase(inputBaseChoice);
            int outputBase = getBase(outputBaseChoice);

            System.out.print("Enter input value: ");
            String inputValue = sc.next().toUpperCase(); 

            try {
                int decimalValue = convertToDecimal(inputValue, inputBase);
                String outputValue = convertFromDecimal(decimalValue, outputBase);
                System.out.println("Output value: " + outputValue);
            } catch (Exception e) {
                System.out.println("Invalid input for the selected base.");
            }

            System.out.print("Do you want to continue? (y/n): ");
            String cont = sc.next();
            if (!cont.equalsIgnoreCase("y")) break;
        }

        sc.close();
    }

    public static int getBase(int choice) {
        if (choice == 1) return 2;
        if (choice == 2) return 10;
        return 16;
    }

    public static int convertToDecimal(String value, int base) {
        int result = 0;
        int power = 1;

        for (int i = value.length() - 1; i >= 0; i--) {
            char c = value.charAt(i);
            int digit;

            if (Character.isDigit(c)) {
                digit = c - '0';
            } else if (c >= 'A' && c <= 'F') {
                digit = c - 'A' + 10;
            } else {
                throw new IllegalArgumentException("Invalid character in input");
            }

            if (digit >= base) {
                throw new IllegalArgumentException("Digit out of range for base " + base);
            }

            result += digit * power;
            power *= base;
        }

        return result;
    }

    public static String convertFromDecimal(int decimal, int base) {
        if (decimal == 0) return "0";

        StringBuilder sb = new StringBuilder();
        while (decimal > 0) {
            int remainder = decimal % base;
            if (remainder < 10) {
                sb.append((char) (remainder + '0'));
            } else {
                sb.append((char) (remainder - 10 + 'A')); 
            }
            decimal /= base;
        }

        return sb.reverse().toString();
    }
}
