package linearsearch;
        import java.util.Scanner;

public class LinearSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of elements: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Number of elements must be positive.");
            return;
        }

        int[] arr = new int[n];
        System.out.print("Generated array: ");
        for (int i = 0; i < n; i++) {
            arr[i] = (int)(Math.random() * 100); 
            System.out.print(arr[i] + " ");
        }

        System.out.print("\nEnter number to search: ");
        int searchNum = sc.nextInt();
        int index = -1;
        for (int i = 0; i < n; i++) {
            if (arr[i] == searchNum) {
                index = i;
                break;
            }
        };

        if (index != -1) {
            System.out.println("Number found at index: " + index);
        } else {
            System.out.println("Number not found in array.");
        }

        sc.close();
    }
}
