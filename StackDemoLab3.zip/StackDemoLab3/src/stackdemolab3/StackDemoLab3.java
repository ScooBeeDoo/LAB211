import java.util.Scanner;

public class StackDemoLab3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter maximum size of stack: ");
        int maxSize = sc.nextInt();

        if (maxSize <= 0) {
            System.out.println("Vui lòng nhập một số nguyên dương!");
            sc.close();
            return;
        }

        MyStack stack = new MyStack(maxSize);

        while (true) {
            System.out.println("\nStack Operations:");
            System.out.println("1. Push");
            System.out.println("2. Pop");
            System.out.println("3. Get top value");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            if (choice == 4) {
                System.out.println("Goodbye!");
                break;
            }

            switch (choice) {
                case 1: 
                    System.out.print("Enter value to push: ");
                    int value = sc.nextInt();
                    stack.push(value);
                    break;
                case 2: 
                    stack.pop();
                    break;
                case 3: 
                    stack.get();
                    break;
                default:
                    System.out.println("Invalid choice! Please choose 1-4.");
            }

            stack.display();
        }

        sc.close();
    }
}

class MyStack {
    private int[] stackValues; 
    private int top; 
    private int maxSize; 

    // Constructor
    public MyStack(int size) {
        maxSize = size;
        stackValues = new int[maxSize];
        top = -1; 
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == maxSize - 1;
    }

    public void push(int value) {
        if (isFull()) {
            System.out.println("Stack is full! Cannot push " + value);
            return;
        }
        top++;
        stackValues[top] = value;
        System.out.println("Pushed " + value + " to stack.");
    }

    public void pop() {
        if (isEmpty()) {
            System.out.println("Stack is empty! Nothing to pop.");
            return;
        }
        int value = stackValues[top];
        top--;
        System.out.println("Popped " + value + " from stack.");
    }

    public void get() {
        if (isEmpty()) {
            System.out.println("Stack is empty! Nothing to get.");
            return;
        }
        System.out.println("Top value: " + stackValues[top]);
    }

    public void display() {
        if (isEmpty()) {
            System.out.println("Stack: []");
            return;
        }
        System.out.print("Stack: [");
        for (int i = 0; i <= top; i++) {
            System.out.print(stackValues[i]);
            if (i < top) {
                System.out.print(",");
            }
        }
        System.out.println("]");
    }
}