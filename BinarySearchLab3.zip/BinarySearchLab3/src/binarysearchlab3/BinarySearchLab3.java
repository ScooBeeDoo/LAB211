import java.util.Scanner;

public class BinarySearchLab3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of array: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("Vui lòng nhập một số nguyên dương!");
            sc.close();
            return;
        }

        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = (int)(Math.random() * 100); 
        }

        System.out.print("Enter search value: ");
        int searchNum = sc.nextInt();

        quickSort(arr, 0, n - 1);

        System.out.print("Sorted array: [");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i]);
            if (i < n - 1) {
                System.out.print(",");
            }
        }
        System.out.println("]");

        int index = binarySearch(arr, searchNum);
        if (index != -1) {
            System.out.println("Found " + searchNum + " at index: " + index);
        } else {
            System.out.println("Value " + searchNum + " not found in array.");
        }

        sc.close();
    }

    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
    }

    public static int partition(int[] arr, int low, int high) {
        int pivot = arr[(low + high) / 2];
        int i = low;
        int j = high;
        while (i <= j) {
            while (arr[i] < pivot) {
                i++;
            }
            while (arr[j] > pivot) {
                j--;
            }
            if (i <= j) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                i++;
                j--;
            }
        }
        return i;
    }

    public static int binarySearch(int[] arr, int searchNum) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = (left + right) / 2;
            if (arr[mid] == searchNum) {
                return mid;
            } else if (arr[mid] < searchNum) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }
}